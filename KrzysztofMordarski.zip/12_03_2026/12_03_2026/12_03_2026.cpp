﻿#include <iostream>
#include "header.h"

using namespace std;

char Klasa::ID = 'A';

Klasa obj1;

Klasa* wskobj10 = new Klasa(10);

int main()
{
    std::cout << "Wchodzimy do funkcji \'main\'"<<endl;

    
    Klasa obj3 = Klasa();
    Klasa obj4 = Klasa(4);
    delete wskobj10;
    

    std::cout << "Wychodzimy z funkcji \'main\'"<<endl;

}

Klasa obiekt2(2);