#include <iostream>
#include "header.h"

Klasa::Klasa() {
    id = ID++;
    a = 0;
    cout << "Ctor()   " << id << a << endl;
};

Klasa::Klasa(int aa) {
    id = ID++;
    a = aa;
    cout << "Ctor()   " << id << a << endl;
}
Klasa::~Klasa() {
    cout << "Dtor()   " << id << a << endl;
};

