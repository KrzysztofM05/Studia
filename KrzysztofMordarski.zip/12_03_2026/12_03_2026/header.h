#include <iostream>
using namespace std;

class Klasa
{
	static char ID;
	int a;
	char id;
public:
	Klasa();
	Klasa(int aa);
	virtual ~Klasa();
};

